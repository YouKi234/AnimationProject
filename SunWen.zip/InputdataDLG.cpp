﻿// InputdataDLG.cpp: 实现文件
//

#include "pch.h"
#include "SunWen.h"
#include "afxdialogex.h"
#include "InputdataDLG.h"


// InputdataDLG 对话框

IMPLEMENT_DYNAMIC(InputdataDLG, CDialogEx)

InputdataDLG::InputdataDLG(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, point1_x(0)
	, point1_y(0)
	, point2_x(0)
	, point2_y(0)
{

}

InputdataDLG::~InputdataDLG()
{
}

void InputdataDLG::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_Point1_x, point1_x);
	DDX_Text(pDX, IDC_Point1_y, point1_y);
	DDX_Text(pDX, IDC_Point2_x, point2_x);
	DDX_Text(pDX, IDC_Point2_y, point2_y);
}


BEGIN_MESSAGE_MAP(InputdataDLG, CDialogEx)
END_MESSAGE_MAP()


// InputdataDLG 消息处理程序
