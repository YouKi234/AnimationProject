﻿#pragma once
#include "afxdialogex.h"


// InputdataDLG 对话框

class InputdataDLG : public CDialogEx
{
	DECLARE_DYNAMIC(InputdataDLG)

public:
	InputdataDLG(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~InputdataDLG();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	float point1_x;
	float point1_y;
	float point2_x;
	float point2_y;
};
